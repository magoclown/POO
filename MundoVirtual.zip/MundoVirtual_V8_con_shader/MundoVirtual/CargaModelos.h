#pragma once
#include <ctime>		
#include <fstream>		
#include <time.h>
#include <gdiplus.h>	
#include <GL/gl.h>		
#include <GL/glu.h>

using namespace std;
using namespace Gdiplus;

namespace objv3RERWIN32
{
	class objLoaderRERWorld_v3_1_WIN32
	{
	public:
		struct objectData
		{
			unsigned int totalFaces;
			unsigned int IDtexture;
			char* objectName;
			char* textureName;
			char *imageName;
			float RGB[3];
			float Shininess;
			float Transparency;
			float specularColor[3];
			bool Texture;
			unsigned int vertNumb;
			unsigned int normNumb;
			unsigned int texcNumb;
			float* sVertices;
			float* sNormals;
			float* sTextureCoords;
		};
		unsigned int totalObjects;
		objectData* Objects;

	public:
		char*  fileName;
		char*  fullName;
		char fileString[100];
		char** Data;
		char** DataFaces;
		float** Vertices;
		float** Normals;
		float** TextureCoords;
		unsigned int totalVertices;
		unsigned int totalNormals;
		unsigned int totalTextureCoords;
		unsigned int mtl;
		unsigned int txtrs;
		float** RGB;
		float** Specular;
		float* Shininess;
		float* Opacity;
		char*** TextureExistence;
		GLuint *IDT;
		char** textureNames;
		WCHAR** Textures;

		int minO, hrO, ddO, mmO, yyyyO;
		int minR, hrR, ddR, mmR, yyyyR;
	public:
		objLoaderRERWorld_v3_1_WIN32() {}
	public:
		/*
		Aqui esta el constructor, solo se necesita la ruta del obj
		*/
		objLoaderRERWorld_v3_1_WIN32(char* objFile)
		{
			cambio = false;
			fileName = objFile;
			totalObjects = 0;
			totalVertices = 0;
			totalNormals = 0;
			totalTextureCoords = 0;
			objLoadAllRERWorld_v3_1();
		}

		~objLoaderRERWorld_v3_1_WIN32()
		{
			delete Objects;
		}
	public:
		void objLoadAllRERWorld_v3_1()
		{
			getDataRERWorld();
			getObjDataToArraysRERWorld();
			getTotalObjectsInfoRERWorld();
			loadMtlFileRERWorld();
			createDataModelFileRERWorld();
		}
	public:
		bool load3DMaxObjFile()
		{
			char *obj3D, *objRER;
			char s1[60], s2[60];
			char **subS1, **subS2;
			char **subSubS1, **subSubS2;
			obj3D = new char[strlen(fileName)];
			objRER = new char[strlen(fileName)];
			strcpy(obj3D, fileName);
			strcpy(objRER, fileName);
			strcat(obj3D, ".obj");
			strcat(objRER, ".objRER");
			ifstream hfileOBJ3D(obj3D, ios::in);
			ifstream hfileOBJRE(objRER, ios::in);
			hfileOBJ3D.getline(s1, 60);
			hfileOBJ3D.getline(s1, 60);
			hfileOBJRE.getline(s2, 60);
			hfileOBJRE.getline(s2, 60);

			subS1 = splitString(s1, " ");
			subS2 = splitString(s2, " ");


			hfileOBJ3D.close();
			hfileOBJRE.close();
			delete obj3D;
			delete objRER;
		}
		void getDataRERWorld()
		{
			fullName = new char[strlen(fileName)];
			strcpy(fullName, fileName);
			strcat(fullName, ".obj");
			ifstream objData(fullName, ios::in);
			while (!objData.eof())
			{
				objData.getline(fileString, 60);
				if (strstr(fileString, "object "))
					totalObjects++;
				else if (strstr(fileString, "v "))
					totalVertices++;
				else if (strstr(fileString, "vn "))
					totalNormals++;
				else if (strstr(fileString, "vt "))
					totalTextureCoords++;

			}
			objData.close();
			//delete objData;
		}

		void getObjDataToArraysRERWorld()
		{
			Vertices = new float*[totalVertices];
			Normals = new float*[totalNormals];
			TextureCoords = new float*[totalTextureCoords];
			for (unsigned int v = 0; v<totalVertices; v++)
				Vertices[v] = new float[3];
			for (unsigned int n = 0; n<totalNormals; n++)
				Normals[n] = new float[3];
			for (unsigned int t = 0; t<totalTextureCoords; t++)
				TextureCoords[t] = new float[2];
			Objects = new objectData[totalObjects];

			int vIndex = 0, nIndex = 0, tIndex = 0, objIndex = 0;
			ifstream objDataStore(fullName, ios::in);

			while (!objDataStore.eof())
			{
				objDataStore.getline(fileString, 100);
				if (strstr(fileString, "v "))
				{
					Data = splitString(fileString, " ");
					for (unsigned int i = 0; i<3; i++)
						Vertices[vIndex][i] = (float)atof(Data[i + 1]);
					vIndex++;
				}
				else if (strstr(fileString, "vn "))
				{
					Data = splitString(fileString, " ");
					for (unsigned int i = 0; i<3; i++)
						Normals[nIndex][i] = (float)atof(Data[i + 1]);
					nIndex++;
				}
				else if (strstr(fileString, "vt "))
				{
					Data = splitString(fileString, " ");
					TextureCoords[tIndex][0] = (float)atof(Data[1]);
					TextureCoords[tIndex][1] = (float)atof(Data[2])*-1;
					tIndex++;
				}
				else if (strstr(fileString, "object "))
				{
					Data = splitString(fileString, " ");
					Objects[objIndex].objectName = new char[strlen(Data[2])];
					strcpy(Objects[objIndex].objectName, Data[2]);
				}
				else if (strstr(fileString, "usemtl "))
				{
					Data = splitString(fileString, " ");
					Objects[objIndex].textureName = new char[strlen(Data[1])];
					strcpy(Objects[objIndex].textureName, Data[1]);
				}
				else if (strstr(fileString, " vertices"))
				{
					Data = splitString(fileString, " ");
					Objects[objIndex].vertNumb = (int)atoi(Data[1]);
				}
				else if (strstr(fileString, " vertex normals"))
				{
					Data = splitString(fileString, " ");
					Objects[objIndex].normNumb = (int)atoi(Data[1]);
				}
				else if (strstr(fileString, " texture coords"))
				{
					Data = splitString(fileString, " ");
					Objects[objIndex].texcNumb = (int)atoi(Data[1]);
				}
				else if (strstr(fileString, " faces"))
				{
					Data = splitString(fileString, " ");
					Objects[objIndex].totalFaces = (int)atoi(Data[1]);
					objIndex++;
				}
			}
			objDataStore.close();
			delete Data;
			//delete objDataStore;
		}

		void getTotalObjectsInfoRERWorld()
		{
			int obj = -1, vIndex = 0, nIndex = 0, tIndex = 0, numberCoord = 0;
			for (unsigned int i = 0; i<totalObjects; i++)
			{
				Objects[i].sVertices = new float[Objects[i].totalFaces * 9];
				Objects[i].sNormals = new float[Objects[i].totalFaces * 9];
				Objects[i].sTextureCoords = new float[Objects[i].totalFaces * 6];
				Objects[i].Texture = false;
			}
			ifstream objData(fullName, ios::in);
			ofstream qwert("puntos.txt", ios::trunc);
			int t = 0;
			while (!objData.eof())
			{
				objData.getline(fileString, 100);
				if (strstr(fileString, "object "))
				{
					obj++;
					vIndex = 0;
					nIndex = 0;
					tIndex = 0;
				}
				else if (strstr(fileString, "f "))
				{
					memcpy(fileString, &fileString[2], sizeof(fileString));
					Data = splitString(fileString, " ");

					/////////////

					//
					for (unsigned int i = 0; i<3; i++)
					{
						/////////
						qwert << "T" << t << "-P" << i;
						//////////
						DataFaces = splitString(Data[i], "/");
						for (unsigned int j = 0; j<3; j++)
						{
							numberCoord = (int)atoi(DataFaces[j]) - 1;
							switch (j)
							{
							case 0:
								Objects[obj].sVertices[vIndex] = Vertices[numberCoord][0];
								Objects[obj].sVertices[vIndex + 1] = Vertices[numberCoord][1];
								Objects[obj].sVertices[vIndex + 2] = Vertices[numberCoord][2];

								qwert << "("
									<< Objects[obj].sVertices[vIndex] << ","
									<< Objects[obj].sVertices[vIndex + 1] << ","
									<< Objects[obj].sVertices[vIndex + 2] << ")\n";
								vIndex += 3;
								break;
							case 1:
								Objects[obj].sTextureCoords[tIndex] = TextureCoords[numberCoord][0];
								Objects[obj].sTextureCoords[tIndex + 1] = TextureCoords[numberCoord][1];
								tIndex += 2;
								break;
							case 2:
								Objects[obj].sNormals[nIndex] = Normals[numberCoord][0];
								Objects[obj].sNormals[nIndex + 1] = Normals[numberCoord][1];
								Objects[obj].sNormals[nIndex + 2] = Normals[numberCoord][2];
								nIndex += 3;
							}
						}
					}
					t++;
					qwert << "\n";
				}
			}
			qwert.close();

			//delete objData;
			delete Data;
			delete DataFaces;
		}

		bool cambio;
		void loadMtlFileRERWorld()
		{
			mtl = txtrs = 0;
			fullName[strlen(fullName) - 4] = 0;
			strcat(fullName, ".mtl");
			ifstream mtlData(fullName, ios::in);
			while (!mtlData.eof())
			{
				mtlData.getline(fileString, 100);
				if (strstr(fileString, "newmtl"))
					mtl++;
				if (strstr(fileString, "map_Kd"))
					txtrs++;
			}
			mtlData.close();
			//delete mtlData;
			//delete mtlData;
			Textures = new WCHAR*[txtrs];
			textureNames = new char*[mtl];
			RGB = new float*[mtl];
			Specular = new float*[mtl];
			for (unsigned int k = 0; k<mtl; k++)
			{
				RGB[k] = new float[3];
				Specular[k] = new float[3];
			}
			Opacity = new float[mtl];
			Shininess = new float[mtl];
			TextureExistence = new char**[txtrs];
			for (unsigned int z = 0; z<txtrs; z++)
				TextureExistence[z] = new char*[3];
			char** path;
			mtl = -1;
			txtrs = -1;

			ifstream mtlDataText(fullName, ios::in);
			while (!mtlDataText.eof())
			{
				mtlDataText.getline(fileString, 100);
				if (strstr(fileString, "newmtl"))
				{
					path = splitString(fileString, " ");
					textureNames[++mtl] = new char[strlen(path[1])];
					strcpy(textureNames[mtl], path[1]);
				}
				else
					if (strstr(fileString, "\tKd "))
					{
						path = splitString(fileString, " ");
						for (unsigned int k = 0; k<3; k++)
							RGB[mtl][k] = (float)atof(path[k + 1]);
					}
				if (strstr(fileString, "\tKs "))
				{
					path = splitString(fileString, " ");
					for (unsigned int k = 0; k<3; k++)
						Specular[mtl][k] = (float)atof(path[k + 1]);
				}
				if (strstr(fileString, "\tNs "))
				{
					path = splitString(fileString, " ");
					Shininess[mtl] = (float)atof(path[1]);
				}
				else
					if (strstr(fileString, "\td "))
					{
						path = splitString(fileString, " ");
						Opacity[mtl] = (float)atof(path[1]);
					}
					else
						if (strstr(fileString, "map_Kd "))
						{
							cambio = true;
							memcpy(fileString, &fileString[8], sizeof(fileString));
							WCHAR fileStringWCHAR[] = L"                                                           ";
							mbstowcs(fileStringWCHAR, fileString, strlen(fileString));
							txtrs++;
							*(Textures + txtrs) = new WCHAR[strlen(fileString)];
							memcpy(Textures[txtrs], fileStringWCHAR, sizeof(WCHAR)*strlen(fileString));
							Textures[txtrs][strlen(fileString)] = 0;
							TextureExistence[txtrs][0] = new char[strlen(textureNames[mtl])];
							strcpy(TextureExistence[txtrs][0], textureNames[mtl]);
							TextureExistence[txtrs][1] = new char[3];
							itoa((int)txtrs, TextureExistence[txtrs][1], 10);
							TextureExistence[txtrs][2] = new char[strlen(fileString)];
							strcpy(TextureExistence[txtrs][2], fileString);
						}
			}
			if (!cambio)
				txtrs = 0;
			mtlDataText.close();
			//delete mtlDataText;
			delete path;
			if (cambio)
				loadTextureRERWorld(txtrs + 1);

			//delete Vertices;
			delete Normals;
			delete TextureCoords;


			assignIDsToObjectsRERWorld();
		}
		void loadTextureRERWorld(int totalTextures)
		{
			GdiplusStartupInput gdiplusStartupInput;
			ULONG_PTR gdiplusToken;
			GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

			WCHAR** tempo;
			tempo = Textures;
			unsigned int **sizeWH, *totalBytes;
			Bitmap** images;
			images = new Bitmap*[totalTextures];
			sizeWH = new unsigned int*[totalTextures];
			totalBytes = new unsigned int[totalTextures];
			for (int n = 0; n<totalTextures; n++, tempo++)
			{
				images[n] = new Bitmap(*tempo);
				sizeWH[n] = new unsigned int[2];
				sizeWH[n][0] = (*images[n]).GetWidth();
				sizeWH[n][1] = (*images[n]).GetHeight();
				totalBytes[n] = sizeWH[n][0] * sizeWH[n][1] * 4;
			}
			unsigned char *texturePointer, *pixelArray, *firstPixel;
			glEnable(GL_TEXTURE_2D);
			IDT = new GLuint[totalTextures];
			glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
			glGenTextures(totalTextures, IDT);
			BitmapData* bitmapData = new BitmapData;
			for (int z = 0; z<totalTextures; z++)
			{
				Rect rect(0, 0, sizeWH[z][0], sizeWH[z][1]);
				(*images[z]).LockBits(&rect, ImageLockModeRead, PixelFormat32bppARGB, bitmapData);
				firstPixel = (unsigned char*)bitmapData->Scan0;
				pixelArray = new unsigned char[totalBytes[z]];
				texturePointer = pixelArray;
				for (unsigned int i = 0; i<totalBytes[z]; i += 4)
				{
					pixelArray[i + 3] = firstPixel[i + 3];
					pixelArray[i + 2] = firstPixel[i];
					pixelArray[i + 1] = firstPixel[i + 1];
					pixelArray[i] = firstPixel[i + 2];
				}
				(*images[z]).UnlockBits(bitmapData);

				glBindTexture(GL_TEXTURE_2D, IDT[z]);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
				gluBuild2DMipmaps(GL_TEXTURE_2D, 3, sizeWH[z][0], sizeWH[z][1], GL_RGBA, GL_UNSIGNED_BYTE, texturePointer);
				glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
				delete pixelArray;
			}
			GdiplusShutdown(gdiplusToken);
			glDisable(GL_TEXTURE_2D);
			delete bitmapData;
			delete sizeWH;
			texturePointer = NULL;
			delete texturePointer;
			delete Textures;
		}
		void assignIDsToObjectsRERWorld()
		{
			for (unsigned int i = 0; i<totalObjects; i++)
			{
				Objects[i].imageName = new char[60];
				strcpy(Objects[i].imageName, "NO IMAGE");
				for (unsigned int j = 0; j <= mtl; j++)
				{
					if (strcmp(Objects[i].textureName, textureNames[j]) == 0)
					{
						for (unsigned int t = 0; t <= txtrs && (t != 0 || cambio); t++)
						{
							if (strcmp(Objects[i].textureName, TextureExistence[t][0]) == 0)
							{
								Objects[i].Texture = true;
								Objects[i].IDtexture = (unsigned int)atoi(TextureExistence[t][1]);
								strcpy(Objects[i].imageName, TextureExistence[t][2]);
								break;
							}
						}
						Objects[i].Transparency = Opacity[j];
						Objects[i].Shininess = Shininess[j];
						for (int c = 0; c<3; c++)
						{
							Objects[i].RGB[c] = RGB[j][c];
							Objects[i].specularColor[c] = Specular[j][c];
						}
						break;
					}
				}
			}
			delete textureNames;
			delete RGB;
			delete Opacity;
			delete Specular;
			if (cambio)
				delete TextureExistence;
		}

		void loadDataModelFileRERWorld()
		{
			fullName = new char[strlen(fileName)];
			strcpy(fullName, fileName);
			strcat(fullName, ".objRER");
			ifstream openFile(fullName, ios::in);
			for (int i = 0; i<16; i++)
				openFile.getline(fileString, 100);
			Data = splitString(fileString, " ");
			totalObjects = (unsigned int)atoi(Data[1]);
			Objects = new objectData[totalObjects];
			openFile.getline(fileString, 100);
			Data = splitString(fileString, " ");
			totalVertices = (unsigned int)atoi(Data[1]);
			openFile.getline(fileString, 100);
			Data = splitString(fileString, " ");
			totalNormals = (unsigned int)atoi(Data[1]);
			openFile.getline(fileString, 100);
			Data = splitString(fileString, " ");
			totalTextureCoords = (unsigned int)atoi(Data[1]);

			Objects = new objectData[totalObjects];

			int contObj = 0;
			while (!openFile.eof())
			{
				openFile.getline(fileString, 100);
				Data = splitString(fileString, " ");
				if (strstr(fileString, "objName "))
				{
					Objects[contObj].objectName = new char[strlen(fileString)];
					strcpy(Objects[contObj].objectName, Data[1]);
				}
				else
					if (strstr(fileString, "matName "))
					{
						Objects[contObj].textureName = new char[strlen(fileString)];
						strcpy(Objects[contObj].textureName, Data[1]);
					}
					else
						if (strstr(fileString, "texName "))
						{
							Objects[contObj].imageName = new char[strlen(fileString)];
							strcpy(Objects[contObj].imageName, Data[1]);
						}
						else
							if (strstr(fileString, "Texture "))
							{
								if (strcmp(Data[1], "1") == 0)
									Objects[contObj].Texture = true;
								else
									Objects[contObj].Texture = false;
							}
							else
								if (strstr(fileString, "IDntext "))
									Objects[contObj].IDtexture = (unsigned int)atoi(Data[1]);
								else
									if (strstr(fileString, "facVN&T "))
									{
										Objects[contObj].sVertices = new float[(unsigned int)atoi(Data[1])];
										Objects[contObj].sNormals = new float[(unsigned int)atoi(Data[1])];
										Objects[contObj].sTextureCoords = new float[(unsigned int)atoi(Data[2])];
										Objects[contObj].vertNumb = (unsigned int)atoi(Data[1]);
										Objects[contObj].normNumb = (unsigned int)atoi(Data[1]);
										Objects[contObj].texcNumb = (unsigned int)atoi(Data[2]);
									}
									else
										if (strstr(fileString, "Vertice "))
										{
											for (unsigned int vrf = 0; vrf<Objects[contObj].vertNumb; vrf += 3)
											{
												openFile.getline(fileString, 100);
												Data = splitString(fileString, " ");
												Objects[contObj].sVertices[vrf] = (float)atof(Data[1]);
												Objects[contObj].sVertices[vrf + 1] = (float)atof(Data[2]);
												Objects[contObj].sVertices[vrf + 2] = (float)atof(Data[3]);
											}
										}
										else
											if (strstr(fileString, "Normals "))
											{
												for (unsigned int nrf = 0; nrf<Objects[contObj].normNumb; nrf += 3)
												{
													openFile.getline(fileString, 100);
													Data = splitString(fileString, " ");
													Objects[contObj].sNormals[nrf] = (float)atof(Data[1]);
													Objects[contObj].sNormals[nrf + 1] = (float)atof(Data[2]);
													Objects[contObj].sNormals[nrf + 2] = (float)atof(Data[3]);
												}
											}
											else
												if (strstr(fileString, "TexCoor "))
												{
													for (unsigned int trf = 0; trf<Objects[contObj].texcNumb; trf += 2)
													{
														openFile.getline(fileString, 100);
														Data = splitString(fileString, " ");
														Objects[contObj].sTextureCoords[trf] = (float)atof(Data[1]);
														Objects[contObj].sTextureCoords[trf + 1] = (float)atof(Data[2]);
													}
												}
												else
													if (strstr(fileString, "RGB_Arr "))
													{
														Objects[contObj].RGB[0] = (float)atof(Data[1]);
														Objects[contObj].RGB[1] = (float)atof(Data[2]);
														Objects[contObj].RGB[2] = (float)atof(Data[3]);
													}
													else
														if (strstr(fileString, "Spec_ar "))
														{
															Objects[contObj].specularColor[0] = (float)atof(Data[1]);
															Objects[contObj].specularColor[1] = (float)atof(Data[2]);
															Objects[contObj].specularColor[2] = (float)atof(Data[3]);
														}
														else
															if (strstr(fileString, "ShinyAr "))
																Objects[contObj].Shininess = (float)atof(Data[1]);
															else
																if (strstr(fileString, "TranspF "))
																	Objects[contObj++].Transparency = (float)atof(Data[1]);
			}
		}
		void createDataModelFileRERWorld()
		{
			fullName[strlen(fullName) - 4] = 0;
			strcat(fullName, ".objRER");
			ofstream saveFile(fullName, ios::trunc);
			time_t now = time(0);
			tm *ltm = localtime(&now);
			saveFile << "# " << fullName << " file - OBJ Exporter\n";
			saveFile << "# File Created: " << ltm->tm_mon << "/" << ltm->tm_mday << "/" << 1900 + ltm->tm_year << " " << ltm->tm_hour << ":" << ltm->tm_min << ":" << ltm->tm_sec << "\n";
			saveFile << "#   This file contains data from a model made on 3D max    \n";
			saveFile << "#   and processed by the C++ class                         \n";
			saveFile << "#   objLoaderRERWorld_v3_1_WIN32.                          \n";
			saveFile << "#   Use this file with objLoaderRERWorld_v3_1_WIN32 class  \n";
			saveFile << "#   to make a faster load of data of the 3D Max model.     \n\n";
			saveFile << "totalObjects " << totalObjects << "\n";
			saveFile << "totalVertces " << totalVertices << "\n";
			saveFile << "totalTCoords " << totalTextureCoords << "\n\n";
			for (unsigned int i = 0; i<totalObjects; i++)
			{
				saveFile << "objName " << Objects[i].objectName << "\n";
				saveFile << "matName " << Objects[i].textureName << "\n";
				saveFile << "texName " << Objects[i].imageName << "\n";
				saveFile << "Texture " << Objects[i].Texture << "\n";
				saveFile << "IDntext " << Objects[i].IDtexture << "\n";
				saveFile << "facVN&T " << Objects[i].totalFaces * 9 << " " << Objects[i].totalFaces * 6 << "\n";
				for (unsigned int vsf = 0; vsf<Objects[i].totalFaces * 9; vsf += 3)
					saveFile << "Vertice " << Objects[i].sVertices[vsf] << " " << Objects[i].sVertices[vsf + 1] << " " << Objects[i].sVertices[vsf + 2] << "\n";
				for (unsigned int nsf = 0; nsf<Objects[i].totalFaces * 9; nsf += 3)
					saveFile << "Normals " << Objects[i].sNormals[nsf] << " " << Objects[i].sNormals[nsf + 1] << " " << Objects[i].sNormals[nsf + 2] << "\n";
				for (unsigned int tsf = 0; tsf<Objects[i].totalFaces * 6; tsf += 2)
					saveFile << "TexCoor " << Objects[i].sTextureCoords[tsf] << " " << Objects[i].sTextureCoords[tsf + 1] << "\n";
				saveFile << "RGB_Arr " << Objects[i].RGB[0] << " " << Objects[i].RGB[1] << " " << Objects[i].RGB[2] << "\n";
				saveFile << "Spec_ar " << Objects[i].specularColor[0] << " " << Objects[i].specularColor[1] << " " << Objects[i].specularColor[2] << "\n";
				saveFile << "ShinyAr " << Objects[i].Shininess << "\n";
				saveFile << "TranspF " << Objects[i].Transparency << "\n\n";
			}
			saveFile.close();
		}

	public:
		/*
		Con esta funcion se dibuja el modelo
		*/
		void RenderRERWorld()
		{
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);
			glEnableClientState(GL_NORMAL_ARRAY);
			glEnableClientState(GL_VERTEX_ARRAY);
			for (unsigned int object = 0; object<totalObjects; object++)
			{
				glEnable(GL_BLEND);
				glEnable(GL_TEXTURE_2D);
				glDepthMask(GL_TRUE);
				if (Objects[object].Texture)
				{
					glBindTexture(GL_TEXTURE_2D, IDT[Objects[object].IDtexture]);
					if (Objects[object].Transparency<1)
						glBlendFunc(GL_SRC_ALPHA, GL_ONE);
				}
				else
				{
					glDisable(GL_TEXTURE_2D);
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				}
				glColor4f(Objects[object].RGB[0], Objects[object].RGB[1], Objects[object].RGB[2], Objects[object].Transparency);

				glVertexPointer(3, GL_FLOAT, 0, Objects[object].sVertices);
				glNormalPointer(GL_FLOAT, 0, Objects[object].sNormals);
				glTexCoordPointer(2, GL_FLOAT, 0, Objects[object].sTextureCoords);
				glLineWidth(3);
				glDrawArrays(GL_TRIANGLES, 0, Objects[object].totalFaces * 3);
				glDisable(GL_TEXTURE_2D);
				glDisable(GL_BLEND);
			}
			glDisableClientState(GL_TEXTURE_COORD_ARRAY);
			glDisableClientState(GL_NORMAL_ARRAY);
			glDisableClientState(GL_VERTEX_ARRAY);
		}


		char** splitString(char src[], char separator[])
		{
			char **newStrings, *aux;
			char tempo[60];
			strcpy(tempo, src);

			int i = 0, j = 0;

			aux = strtok(src, separator);
			while (aux != NULL)
			{
				aux = strtok(NULL, separator);
				i++;
			}
			newStrings = new char*[i];
			strcpy(src, tempo);
			aux = strtok(src, separator);
			while (aux != NULL)
			{
				newStrings[j++] = new char[strlen(aux)];
				aux = strtok(NULL, separator);
			}
			strcpy(src, tempo);
			aux = strtok(src, separator);
			j = 0;
			while (aux != NULL)
			{
				*(newStrings + j) = aux;
				j++;
				aux = strtok(NULL, separator);
			}
			return newStrings;

		}

	};
}