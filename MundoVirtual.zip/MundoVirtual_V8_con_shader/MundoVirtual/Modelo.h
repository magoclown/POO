#ifndef _modelo
#define _modelo
#include "Geometrias.h"
#include "Imagenes.h"
#include "ShaderDemo.h"
#include "Modelos3D.h"

class Modelo
{

private:	
	Modelos3D *obj;
	ShaderDemo *gpuDemo;

public:	
	int verx, verz;
	//el nombre numerico de la textura en cuestion, por lo pronto una
	unsigned int planoTextura;

	Modelo(HWND hWnd)
	{
		obj = new Modelos3D("c:\\demo\\tetera.obj");
		gpuDemo = new ShaderDemo("basic.vert", "basic.frag");
		gpuDemo->ligador(gpuDemo->vertShader, gpuDemo->fragShader);
	}

	~Modelo()
	{
		//nos aseguramos de disponer de los recursos previamente reservados
		delete obj;		
		glDeleteTextures(1, &planoTextura);
	}

	void Draw()
	{
		int ind = 0;
		int indice;

		//habilitamos el culling para reducir tiempo de procesamiento de las texturas
		//las texturas se analizan pixel a pixel para determinar que se imprimen o no
		//por lo que aunque no la veamos nos costo, por eso la eliminamos.
		glEnable(GL_CULL_FACE);
		//hay dos tipos de cull el frontal y el trasero (back)
		glCullFace(GL_BACK);
		//habilitamos la textura, podriamos mezclar colores y cambiar la tonalidad de la textura
		//con glColorxf
		glEnable(GL_TEXTURE_2D);
		//usamos modulate para que la textura sea afectada por el valor de la normal en cuanto
		//a luz
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		gpuDemo->use();
		glBindTexture(GL_TEXTURE_2D, planoTextura);
		//habilitamos la posibilidad de guardar arreglos de procesamiento inmediato
		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_NORMAL_ARRAY);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);

		//asignamos punteros de vertices, normales y texturas al buffer de conexiones que sigue
		glVertexPointer(3, GL_FLOAT, sizeof(Vertices), &obj->modelo.vertices);
		glNormalPointer(GL_FLOAT, sizeof(Vertices), &obj->modelo.normales);
		glTexCoordPointer(2, GL_FLOAT, sizeof(Vertices), &obj->modelo.texturas);

		GLfloat wm[16];
		glGetFloatv(GL_MODELVIEW_MATRIX, wm);
		gpuDemo->PonValorM4x4("WorldMatrix", wm);
		//conectamos todos los vertices previamente cargados a traves de sus punteros para procesarse
		glDrawElements(GL_TRIANGLES, (obj->cantfaces), GL_UNSIGNED_INT, (int *)obj->indice);
		//desocupamos la asignacion para que podamos utilizarlo con un nuevo elemento
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		glDisable(GL_CULL_FACE);
		gpuDemo->desuse();
	}

	
};

#endif 